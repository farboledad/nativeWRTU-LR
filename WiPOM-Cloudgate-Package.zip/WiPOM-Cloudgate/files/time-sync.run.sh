#!/bin/sh

# CG9101-nanoWiPOM

while true; do
	# start wrtusrv
	ntpdate pool.ntp.org

	sleep 60
done
